IES Utilities
===========================
This package contains utility functions for working with .ies (Illuminating Engineering Society) photometric files.

Install
----------

On Linux: simply run 'make install'.

Usage
----------

License
----------
